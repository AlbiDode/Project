/**
 */
package behaviour;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Expr Operation</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link behaviour.ExprOperation#getOperator <em>Operator</em>}</li>
 *   <li>{@link behaviour.ExprOperation#getOperands <em>Operands</em>}</li>
 * </ul>
 *
 * @see behaviour.BehaviourPackage#getExprOperation()
 * @model
 * @generated
 */
public interface ExprOperation extends Expression {
	/**
	 * Returns the value of the '<em><b>Operator</b></em>' attribute.
	 * The literals are from the enumeration {@link behaviour.Operator}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Operator</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Operator</em>' attribute.
	 * @see behaviour.Operator
	 * @see #setOperator(Operator)
	 * @see behaviour.BehaviourPackage#getExprOperation_Operator()
	 * @model dataType="behaviour.Operator"
	 * @generated
	 */
	Operator getOperator();

	/**
	 * Sets the value of the '{@link behaviour.ExprOperation#getOperator <em>Operator</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Operator</em>' attribute.
	 * @see behaviour.Operator
	 * @see #getOperator()
	 * @generated
	 */
	void setOperator(Operator value);

	/**
	 * Returns the value of the '<em><b>Operands</b></em>' containment reference list.
	 * The list contents are of type {@link behaviour.Expression}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Operands</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Operands</em>' containment reference list.
	 * @see behaviour.BehaviourPackage#getExprOperation_Operands()
	 * @model containment="true" lower="2" upper="2"
	 * @generated
	 */
	EList<Expression> getOperands();

} // ExprOperation
