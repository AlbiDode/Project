/**
 */
package behaviour;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>For</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link behaviour.For#getBody <em>Body</em>}</li>
 *   <li>{@link behaviour.For#getCondition <em>Condition</em>}</li>
 *   <li>{@link behaviour.For#getAfterthought <em>Afterthought</em>}</li>
 *   <li>{@link behaviour.For#getInitName <em>Init Name</em>}</li>
 *   <li>{@link behaviour.For#getInitType <em>Init Type</em>}</li>
 *   <li>{@link behaviour.For#getInitAssignment <em>Init Assignment</em>}</li>
 * </ul>
 *
 * @see behaviour.BehaviourPackage#getFor()
 * @model
 * @generated
 */
public interface For extends Statement {
	/**
	 * Returns the value of the '<em><b>Body</b></em>' containment reference list.
	 * The list contents are of type {@link behaviour.Statement}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Body</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Body</em>' containment reference list.
	 * @see behaviour.BehaviourPackage#getFor_Body()
	 * @model containment="true"
	 * @generated
	 */
	EList<Statement> getBody();

	/**
	 * Returns the value of the '<em><b>Condition</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Condition</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Condition</em>' containment reference.
	 * @see #setCondition(Expression)
	 * @see behaviour.BehaviourPackage#getFor_Condition()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Expression getCondition();

	/**
	 * Sets the value of the '{@link behaviour.For#getCondition <em>Condition</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Condition</em>' containment reference.
	 * @see #getCondition()
	 * @generated
	 */
	void setCondition(Expression value);

	/**
	 * Returns the value of the '<em><b>Afterthought</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Afterthought</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Afterthought</em>' containment reference.
	 * @see #setAfterthought(Expression)
	 * @see behaviour.BehaviourPackage#getFor_Afterthought()
	 * @model containment="true"
	 * @generated
	 */
	Expression getAfterthought();

	/**
	 * Sets the value of the '{@link behaviour.For#getAfterthought <em>Afterthought</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Afterthought</em>' containment reference.
	 * @see #getAfterthought()
	 * @generated
	 */
	void setAfterthought(Expression value);

	/**
	 * Returns the value of the '<em><b>Init Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Init Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Init Name</em>' attribute.
	 * @see #setInitName(String)
	 * @see behaviour.BehaviourPackage#getFor_InitName()
	 * @model
	 * @generated
	 */
	String getInitName();

	/**
	 * Sets the value of the '{@link behaviour.For#getInitName <em>Init Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Init Name</em>' attribute.
	 * @see #getInitName()
	 * @generated
	 */
	void setInitName(String value);

	/**
	 * Returns the value of the '<em><b>Init Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Init Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Init Type</em>' attribute.
	 * @see #setInitType(String)
	 * @see behaviour.BehaviourPackage#getFor_InitType()
	 * @model
	 * @generated
	 */
	String getInitType();

	/**
	 * Sets the value of the '{@link behaviour.For#getInitType <em>Init Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Init Type</em>' attribute.
	 * @see #getInitType()
	 * @generated
	 */
	void setInitType(String value);

	/**
	 * Returns the value of the '<em><b>Init Assignment</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Init Assignment</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Init Assignment</em>' containment reference.
	 * @see #setInitAssignment(Expression)
	 * @see behaviour.BehaviourPackage#getFor_InitAssignment()
	 * @model containment="true"
	 * @generated
	 */
	Expression getInitAssignment();

	/**
	 * Sets the value of the '{@link behaviour.For#getInitAssignment <em>Init Assignment</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Init Assignment</em>' containment reference.
	 * @see #getInitAssignment()
	 * @generated
	 */
	void setInitAssignment(Expression value);

} // For
