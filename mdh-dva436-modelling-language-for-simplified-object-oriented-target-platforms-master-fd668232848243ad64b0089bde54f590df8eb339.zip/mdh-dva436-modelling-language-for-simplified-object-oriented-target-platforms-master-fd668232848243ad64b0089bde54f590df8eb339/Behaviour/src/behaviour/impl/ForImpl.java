/**
 */
package behaviour.impl;

import behaviour.BehaviourPackage;
import behaviour.Expression;
import behaviour.For;
import behaviour.Statement;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>For</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link behaviour.impl.ForImpl#getBody <em>Body</em>}</li>
 *   <li>{@link behaviour.impl.ForImpl#getCondition <em>Condition</em>}</li>
 *   <li>{@link behaviour.impl.ForImpl#getAfterthought <em>Afterthought</em>}</li>
 *   <li>{@link behaviour.impl.ForImpl#getInitName <em>Init Name</em>}</li>
 *   <li>{@link behaviour.impl.ForImpl#getInitType <em>Init Type</em>}</li>
 *   <li>{@link behaviour.impl.ForImpl#getInitAssignment <em>Init Assignment</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ForImpl extends StatementImpl implements For {
	/**
	 * The cached value of the '{@link #getBody() <em>Body</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBody()
	 * @generated
	 * @ordered
	 */
	protected EList<Statement> body;

	/**
	 * The cached value of the '{@link #getCondition() <em>Condition</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCondition()
	 * @generated
	 * @ordered
	 */
	protected Expression condition;

	/**
	 * The cached value of the '{@link #getAfterthought() <em>Afterthought</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAfterthought()
	 * @generated
	 * @ordered
	 */
	protected Expression afterthought;

	/**
	 * The default value of the '{@link #getInitName() <em>Init Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInitName()
	 * @generated
	 * @ordered
	 */
	protected static final String INIT_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getInitName() <em>Init Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInitName()
	 * @generated
	 * @ordered
	 */
	protected String initName = INIT_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getInitType() <em>Init Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInitType()
	 * @generated
	 * @ordered
	 */
	protected static final String INIT_TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getInitType() <em>Init Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInitType()
	 * @generated
	 * @ordered
	 */
	protected String initType = INIT_TYPE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getInitAssignment() <em>Init Assignment</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInitAssignment()
	 * @generated
	 * @ordered
	 */
	protected Expression initAssignment;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ForImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return BehaviourPackage.Literals.FOR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Statement> getBody() {
		if (body == null) {
			body = new EObjectContainmentEList<Statement>(Statement.class, this, BehaviourPackage.FOR__BODY);
		}
		return body;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Expression getCondition() {
		return condition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetCondition(Expression newCondition, NotificationChain msgs) {
		Expression oldCondition = condition;
		condition = newCondition;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, BehaviourPackage.FOR__CONDITION, oldCondition, newCondition);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCondition(Expression newCondition) {
		if (newCondition != condition) {
			NotificationChain msgs = null;
			if (condition != null)
				msgs = ((InternalEObject)condition).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - BehaviourPackage.FOR__CONDITION, null, msgs);
			if (newCondition != null)
				msgs = ((InternalEObject)newCondition).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - BehaviourPackage.FOR__CONDITION, null, msgs);
			msgs = basicSetCondition(newCondition, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, BehaviourPackage.FOR__CONDITION, newCondition, newCondition));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Expression getAfterthought() {
		return afterthought;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetAfterthought(Expression newAfterthought, NotificationChain msgs) {
		Expression oldAfterthought = afterthought;
		afterthought = newAfterthought;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, BehaviourPackage.FOR__AFTERTHOUGHT, oldAfterthought, newAfterthought);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAfterthought(Expression newAfterthought) {
		if (newAfterthought != afterthought) {
			NotificationChain msgs = null;
			if (afterthought != null)
				msgs = ((InternalEObject)afterthought).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - BehaviourPackage.FOR__AFTERTHOUGHT, null, msgs);
			if (newAfterthought != null)
				msgs = ((InternalEObject)newAfterthought).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - BehaviourPackage.FOR__AFTERTHOUGHT, null, msgs);
			msgs = basicSetAfterthought(newAfterthought, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, BehaviourPackage.FOR__AFTERTHOUGHT, newAfterthought, newAfterthought));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getInitName() {
		return initName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setInitName(String newInitName) {
		String oldInitName = initName;
		initName = newInitName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, BehaviourPackage.FOR__INIT_NAME, oldInitName, initName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getInitType() {
		return initType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setInitType(String newInitType) {
		String oldInitType = initType;
		initType = newInitType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, BehaviourPackage.FOR__INIT_TYPE, oldInitType, initType));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Expression getInitAssignment() {
		return initAssignment;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetInitAssignment(Expression newInitAssignment, NotificationChain msgs) {
		Expression oldInitAssignment = initAssignment;
		initAssignment = newInitAssignment;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, BehaviourPackage.FOR__INIT_ASSIGNMENT, oldInitAssignment, newInitAssignment);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setInitAssignment(Expression newInitAssignment) {
		if (newInitAssignment != initAssignment) {
			NotificationChain msgs = null;
			if (initAssignment != null)
				msgs = ((InternalEObject)initAssignment).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - BehaviourPackage.FOR__INIT_ASSIGNMENT, null, msgs);
			if (newInitAssignment != null)
				msgs = ((InternalEObject)newInitAssignment).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - BehaviourPackage.FOR__INIT_ASSIGNMENT, null, msgs);
			msgs = basicSetInitAssignment(newInitAssignment, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, BehaviourPackage.FOR__INIT_ASSIGNMENT, newInitAssignment, newInitAssignment));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case BehaviourPackage.FOR__BODY:
				return ((InternalEList<?>)getBody()).basicRemove(otherEnd, msgs);
			case BehaviourPackage.FOR__CONDITION:
				return basicSetCondition(null, msgs);
			case BehaviourPackage.FOR__AFTERTHOUGHT:
				return basicSetAfterthought(null, msgs);
			case BehaviourPackage.FOR__INIT_ASSIGNMENT:
				return basicSetInitAssignment(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case BehaviourPackage.FOR__BODY:
				return getBody();
			case BehaviourPackage.FOR__CONDITION:
				return getCondition();
			case BehaviourPackage.FOR__AFTERTHOUGHT:
				return getAfterthought();
			case BehaviourPackage.FOR__INIT_NAME:
				return getInitName();
			case BehaviourPackage.FOR__INIT_TYPE:
				return getInitType();
			case BehaviourPackage.FOR__INIT_ASSIGNMENT:
				return getInitAssignment();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case BehaviourPackage.FOR__BODY:
				getBody().clear();
				getBody().addAll((Collection<? extends Statement>)newValue);
				return;
			case BehaviourPackage.FOR__CONDITION:
				setCondition((Expression)newValue);
				return;
			case BehaviourPackage.FOR__AFTERTHOUGHT:
				setAfterthought((Expression)newValue);
				return;
			case BehaviourPackage.FOR__INIT_NAME:
				setInitName((String)newValue);
				return;
			case BehaviourPackage.FOR__INIT_TYPE:
				setInitType((String)newValue);
				return;
			case BehaviourPackage.FOR__INIT_ASSIGNMENT:
				setInitAssignment((Expression)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case BehaviourPackage.FOR__BODY:
				getBody().clear();
				return;
			case BehaviourPackage.FOR__CONDITION:
				setCondition((Expression)null);
				return;
			case BehaviourPackage.FOR__AFTERTHOUGHT:
				setAfterthought((Expression)null);
				return;
			case BehaviourPackage.FOR__INIT_NAME:
				setInitName(INIT_NAME_EDEFAULT);
				return;
			case BehaviourPackage.FOR__INIT_TYPE:
				setInitType(INIT_TYPE_EDEFAULT);
				return;
			case BehaviourPackage.FOR__INIT_ASSIGNMENT:
				setInitAssignment((Expression)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case BehaviourPackage.FOR__BODY:
				return body != null && !body.isEmpty();
			case BehaviourPackage.FOR__CONDITION:
				return condition != null;
			case BehaviourPackage.FOR__AFTERTHOUGHT:
				return afterthought != null;
			case BehaviourPackage.FOR__INIT_NAME:
				return INIT_NAME_EDEFAULT == null ? initName != null : !INIT_NAME_EDEFAULT.equals(initName);
			case BehaviourPackage.FOR__INIT_TYPE:
				return INIT_TYPE_EDEFAULT == null ? initType != null : !INIT_TYPE_EDEFAULT.equals(initType);
			case BehaviourPackage.FOR__INIT_ASSIGNMENT:
				return initAssignment != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (InitName: ");
		result.append(initName);
		result.append(", InitType: ");
		result.append(initType);
		result.append(')');
		return result.toString();
	}

} //ForImpl
