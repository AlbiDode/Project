/**
 */
package classStructure;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Structure</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link classStructure.Structure#getClasses <em>Classes</em>}</li>
 *   <li>{@link classStructure.Structure#getMainClass <em>Main Class</em>}</li>
 * </ul>
 *
 * @see classStructure.ClassStructurePackage#getStructure()
 * @model
 * @generated
 */
public interface Structure extends EObject {
	/**
	 * Returns the value of the '<em><b>Classes</b></em>' containment reference list.
	 * The list contents are of type {@link classStructure.Class}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Classes</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Classes</em>' containment reference list.
	 * @see classStructure.ClassStructurePackage#getStructure_Classes()
	 * @model containment="true"
	 * @generated
	 */
	EList<classStructure.Class> getClasses();

	/**
	 * Returns the value of the '<em><b>Main Class</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Main Class</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Main Class</em>' reference.
	 * @see #setMainClass(classStructure.Class)
	 * @see classStructure.ClassStructurePackage#getStructure_MainClass()
	 * @model
	 * @generated
	 */
	classStructure.Class getMainClass();

	/**
	 * Sets the value of the '{@link classStructure.Structure#getMainClass <em>Main Class</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Main Class</em>' reference.
	 * @see #getMainClass()
	 * @generated
	 */
	void setMainClass(classStructure.Class value);

} // Structure
