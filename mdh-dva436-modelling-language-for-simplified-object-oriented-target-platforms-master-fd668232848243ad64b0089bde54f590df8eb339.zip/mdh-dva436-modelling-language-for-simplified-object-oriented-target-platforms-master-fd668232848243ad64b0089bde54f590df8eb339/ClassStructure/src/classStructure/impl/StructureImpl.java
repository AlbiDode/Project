/**
 */
package classStructure.impl;

import classStructure.ClassStructurePackage;
import classStructure.Structure;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Structure</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link classStructure.impl.StructureImpl#getClasses <em>Classes</em>}</li>
 *   <li>{@link classStructure.impl.StructureImpl#getMainClass <em>Main Class</em>}</li>
 * </ul>
 *
 * @generated
 */
public class StructureImpl extends MinimalEObjectImpl.Container implements Structure {
	/**
	 * The cached value of the '{@link #getClasses() <em>Classes</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getClasses()
	 * @generated
	 * @ordered
	 */
	protected EList<classStructure.Class> classes;

	/**
	 * The cached value of the '{@link #getMainClass() <em>Main Class</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMainClass()
	 * @generated
	 * @ordered
	 */
	protected classStructure.Class mainClass;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected StructureImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ClassStructurePackage.Literals.STRUCTURE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<classStructure.Class> getClasses() {
		if (classes == null) {
			classes = new EObjectContainmentEList<classStructure.Class>(classStructure.Class.class, this, ClassStructurePackage.STRUCTURE__CLASSES);
		}
		return classes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public classStructure.Class getMainClass() {
		if (mainClass != null && mainClass.eIsProxy()) {
			InternalEObject oldMainClass = (InternalEObject)mainClass;
			mainClass = (classStructure.Class)eResolveProxy(oldMainClass);
			if (mainClass != oldMainClass) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ClassStructurePackage.STRUCTURE__MAIN_CLASS, oldMainClass, mainClass));
			}
		}
		return mainClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public classStructure.Class basicGetMainClass() {
		return mainClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMainClass(classStructure.Class newMainClass) {
		classStructure.Class oldMainClass = mainClass;
		mainClass = newMainClass;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ClassStructurePackage.STRUCTURE__MAIN_CLASS, oldMainClass, mainClass));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case ClassStructurePackage.STRUCTURE__CLASSES:
				return ((InternalEList<?>)getClasses()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ClassStructurePackage.STRUCTURE__CLASSES:
				return getClasses();
			case ClassStructurePackage.STRUCTURE__MAIN_CLASS:
				if (resolve) return getMainClass();
				return basicGetMainClass();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ClassStructurePackage.STRUCTURE__CLASSES:
				getClasses().clear();
				getClasses().addAll((Collection<? extends classStructure.Class>)newValue);
				return;
			case ClassStructurePackage.STRUCTURE__MAIN_CLASS:
				setMainClass((classStructure.Class)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ClassStructurePackage.STRUCTURE__CLASSES:
				getClasses().clear();
				return;
			case ClassStructurePackage.STRUCTURE__MAIN_CLASS:
				setMainClass((classStructure.Class)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ClassStructurePackage.STRUCTURE__CLASSES:
				return classes != null && !classes.isEmpty();
			case ClassStructurePackage.STRUCTURE__MAIN_CLASS:
				return mainClass != null;
		}
		return super.eIsSet(featureID);
	}

} //StructureImpl
