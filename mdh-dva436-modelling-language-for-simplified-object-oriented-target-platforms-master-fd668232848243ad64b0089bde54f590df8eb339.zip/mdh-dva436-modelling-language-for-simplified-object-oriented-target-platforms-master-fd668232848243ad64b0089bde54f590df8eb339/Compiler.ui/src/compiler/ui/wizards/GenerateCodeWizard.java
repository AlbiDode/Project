package compiler.ui.wizards;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Map;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

import behaviour.Behaviour;
import behaviour.BehaviourPackage;
import classStructure.ClassStructurePackage;
import classStructure.Structure;
import compiler.codegen.Models2Cs;
import compiler.codegen.Models2Java;

public class GenerateCodeWizard extends Wizard {

	protected Path lastSelectedFolder = null;

	protected GenerateCodeWizardOne one;

	public GenerateCodeWizard() {
		super();
		setNeedsProgressMonitor(true);
	}

	@Override
	public String getWindowTitle() {
		return "Generate Code Setup";
	}

	@Override
	public void addPages() {
		one = new GenerateCodeWizardOne();
		this.addPage(one);
	}

	public void update() {
		this.getContainer().updateButtons();

		if (one.getOutputFilename().length() == 0) {
			if (one.getBehaviourFilename().length() != 0) {
				one.setOutputFilename(this.generateOutputFilename(one.getBehaviourFilename()));
			} else if (one.getClassStructureFilename().length() != 0) {
				one.setOutputFilename(this.generateOutputFilename(one.getClassStructureFilename()));
			}
		}
	}

	private String generateOutputFilename(String filename) {
		String path = filename.substring(0, filename.lastIndexOf('.'));
		String extension = "";

		switch (one.getTargetLanguage()) {
		case "Java":
			extension = ".java";
			break;
		case "C#":
			extension = ".cs";
			break;
		}

		return path + extension;
	}

	@Override
	public boolean canFinish() {
		String targetLanguage = one.getTargetLanguage();
		String outputFileName = one.getOutputFilename();

		if (one.getBehaviourFilename().length() == 0 || one.getClassStructureFilename().length() == 0
				|| targetLanguage.length() == 0 || outputFileName.length() == 0) {
			return false;
		}

		String extention = outputFileName.substring(outputFileName.lastIndexOf('.'));

		switch (extention) {
		case ".java":
			if (!targetLanguage.equals("Java"))
				return false;
			break;
		case ".cs":
			if (!targetLanguage.equals("C#"))
				return false;
			break;

		default:
			return false;
		}

		return true;
	}

	@Override
	public boolean performFinish() {
		// Open files
		File behaviourFile = new File(one.getBehaviourFilename());
		File structureFile = new File(one.getClassStructureFilename());

		// Load models
		Structure structure = this.loadClassStructure(structureFile);
		Behaviour behaviour = this.loadBehaviour(behaviourFile);

		String code = "";

		// Run code generator
		switch (one.getTargetLanguage()) {
		case "Java":
			Models2Java p2j = new Models2Java();
			code = p2j.generateCode(structure, behaviour);
			break;
		case "C#":
			Models2Cs m2cs = new Models2Cs();
			code = m2cs.generateCode(structure, behaviour);
			break;
		}

		// Save code to file
		File programFile = new File(one.getOutputFilename());
		this.saveProgram(programFile, code);

		// Refresh the parent folder to have the new file show up in the UI
		for (IProject project : ResourcesPlugin.getWorkspace().getRoot().getProjects()) {
			try {
				project.refreshLocal(IResource.DEPTH_INFINITE, new NullProgressMonitor());
			} catch (CoreException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return true;
	}

	protected Behaviour loadBehaviour(File file) {
		// Initialize the model
		BehaviourPackage.eINSTANCE.eClass();

		// Register the XMI resource factory for the .intermediate extension
		Resource.Factory.Registry reg = Resource.Factory.Registry.INSTANCE;
		Map<String, Object> m = reg.getExtensionToFactoryMap();
		m.put("behaviour", new XMIResourceFactoryImpl());

		// Obtain a new resource set
		ResourceSet resSet = new ResourceSetImpl();

		// Get the resource
		String locationUri = file.getAbsolutePath();
		URI uri = URI.createFileURI(locationUri);
		Resource resource = resSet.getResource(uri, true);

		// Get the first model element and cast it to the right type, in our
		// case everything is hierarchical included in this first node
		Behaviour behaviour = (Behaviour) resource.getContents().get(0);

		return behaviour;
	}

	protected Structure loadClassStructure(File file) {
		// Initialize the model
		ClassStructurePackage.eINSTANCE.eClass();

		// Register the XMI resource factory for the .intermediate extension
		Resource.Factory.Registry reg = Resource.Factory.Registry.INSTANCE;
		Map<String, Object> m = reg.getExtensionToFactoryMap();
		m.put("classStructure", new XMIResourceFactoryImpl());

		// Obtain a new resource set
		ResourceSet resSet = new ResourceSetImpl();

		// Get the resource
		String locationUri = file.getAbsolutePath();
		URI uri = URI.createFileURI(locationUri);
		Resource resource = resSet.getResource(uri, true);

		// Get the first model element and cast it to the right type, in our
		// case everything is hierarchical included in this first node
		Structure classStructure = (Structure) resource.getContents().get(0);

		return classStructure;
	}

	/**
	 * Saves the given program in the given file.
	 *
	 * @param file
	 *            the file to save the program to.
	 * @param programCode
	 *            the program code to save.
	 */
	protected void saveProgram(File file, String programCode) {

		try {
			if (!file.exists()) {
				file.createNewFile();
			}

			FileWriter fw = new FileWriter(file, false);
			fw.write(programCode);
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	class GenerateCodeWizardOne extends WizardPage {
		private FileChooser behaviourFC;
		private FileChooser classStructureFC;
		private Combo targetLanguageCB;
		private FileChooser outputFC;

		private Composite container;

		public GenerateCodeWizardOne() {
			super("Generate Code Setup");
			setTitle("Generate Code Setup");
			setDescription(
					"Choose Behaviour and ClassStructure model files, select target language, and select output file.\nNote: C# support is experimental");
		}

		@Override
		public void createControl(Composite parent) {
			container = new Composite(parent, SWT.NONE);
			GridLayout layout = new GridLayout();
			container.setLayout(layout);
			layout.numColumns = 2;

			GridData gd = new GridData(GridData.FILL_HORIZONTAL);

			// Behaviour file chooser
			Label behaviourLB = new Label(container, SWT.NONE);
			behaviourLB.setText("Behaviour model file:");

			behaviourFC = new FileChooser(container);
			behaviourFC.setEditable(false);
			behaviourFC.setFileDialogText("Select Behaviour model");
			behaviourFC.setFileDialogFilterExtensions(new String[] { "*.behaviour" });
			behaviourFC.setFileDialogFilterNames(new String[] { "Behaviour (*.behaviour)" });
			behaviourFC.setLayoutData(gd);

			// ClassStructure file chooser
			Label classStructureLB = new Label(container, SWT.NONE);
			classStructureLB.setText("Class structure model file:");

			classStructureFC = new FileChooser(container);
			classStructureFC.setEditable(false);
			classStructureFC.setFileDialogText("Select Class Structure model");
			classStructureFC.setFileDialogFilterExtensions(new String[] { "*.classstructure" });
			classStructureFC.setFileDialogFilterNames(new String[] { "Class Structure (*.classstructure)" });
			classStructureFC.setLayoutData(gd);

			// Target language chooser
			Label targetLanguageLB = new Label(container, SWT.NONE);
			targetLanguageLB.setText("Target language:");

			String targetLanguages[] = { "Java", "C#" };
			targetLanguageCB = new Combo(container, SWT.READ_ONLY);
			targetLanguageCB.setItems(targetLanguages);
			targetLanguageCB.select(0);
			targetLanguageCB.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
			targetLanguageCB.addSelectionListener(new SelectionListener() {
				@Override
				public void widgetDefaultSelected(SelectionEvent e) {
				}

				@Override
				public void widgetSelected(SelectionEvent e) {
					// Update wizard buttons
					GenerateCodeWizard.this.update();
				}
			});

			// Output file file
			Label outputFileLB = new Label(container, SWT.NONE);
			outputFileLB.setText("Output file:");

			outputFC = new FileChooser(container);
			outputFC.setFileDialogText("Select output file");
			outputFC.setFileDialogFilterExtensions(new String[] { "*.java", "*.cs" });
			outputFC.setFileDialogFilterNames(new String[] { "Java (*.java)", "C# (*.cs)" });
			outputFC.setLayoutData(gd);

			// required to avoid an error in the system
			setControl(container);
			// setPageComplete(false);
		}

		public String getBehaviourFilename() {
			return behaviourFC.getText();
		}

		public String getClassStructureFilename() {
			return classStructureFC.getText();
		}

		public String getTargetLanguage() {
			return targetLanguageCB.getText();
		}

		public String getOutputFilename() {
			return outputFC.getText();
		}

		public void setOutputFilename(String filename) {
			outputFC.setText(filename);
		}
	}

	class FileChooser extends Composite {

		Text mText;
		Button mButton;
		String title = null;

		String fileDialogText;
		String[] fileDialogFilterExtensions;
		String[] fileDialogFilterNames;

		public FileChooser(Composite parent) {
			super(parent, SWT.NULL);
			createContent();
		}

		public void createContent() {
			GridLayout layout = new GridLayout(2, false);
			setLayout(layout);

			mText = new Text(this, SWT.SINGLE | SWT.BORDER | SWT.READ_ONLY);
			GridData gd = new GridData(GridData.FILL_BOTH);
			gd.grabExcessHorizontalSpace = true;
			gd.horizontalAlignment = GridData.FILL;
			mText.setLayoutData(gd);
			mText.setEditable(true);
			mText.addKeyListener(new KeyListener() {

				@Override
				public void keyPressed(KeyEvent e) {
					// TODO Auto-generated method stub
				}

				@Override
				public void keyReleased(KeyEvent e) {
					// Update wizard buttons
					GenerateCodeWizard.this.update();
				}
			});

			mButton = new Button(this, SWT.NONE);
			mButton.setText("...");
			mButton.addSelectionListener(new SelectionListener() {
				@Override
				public void widgetDefaultSelected(SelectionEvent e) {
				}

				@Override
				public void widgetSelected(SelectionEvent e) {
					FileDialog dlg = new FileDialog(mButton.getShell(), SWT.OPEN);

					// Set the text
					if (fileDialogText != null)
						dlg.setText(fileDialogText);

					// Set filter on files
					if (fileDialogFilterExtensions != null)
						dlg.setFilterExtensions(fileDialogFilterExtensions);

					// Put in a readable name for the filter
					if (fileDialogFilterNames != null)
						dlg.setFilterNames(fileDialogFilterNames);

					// Set path to current workspace
					Path p = Paths.get(getText());

					// Set path to currently selected file folder
					if (getText().length() != 0)
						dlg.setFilterPath(p.getParent().toString());
					// Set path to last selected file in wizard
					else if (GenerateCodeWizard.this.lastSelectedFolder != null)
						dlg.setFilterPath(GenerateCodeWizard.this.lastSelectedFolder.toString());
					// Set path to current workspace
					else
						dlg.setFilterPath(ResourcesPlugin.getWorkspace().getRoot().getLocation().toString());

					// Open file chooser
					String path = dlg.open();

					// Store results
					if (path == null)
						return;
					mText.setText(path);

					// Remember last used path
					GenerateCodeWizard.this.lastSelectedFolder = Paths.get(path).getParent();

					// Update wizard buttons
					GenerateCodeWizard.this.update();
				}
			});
		}

		public void setEditable(boolean editable) {
			mText.setEditable(editable);
			mText.setEnabled(editable);
		}

		public void setFileDialogText(String text) {
			fileDialogText = text;
		}

		public void setFileDialogFilterExtensions(String[] extensions) {
			fileDialogFilterExtensions = extensions;
		}

		public void setFileDialogFilterNames(String[] names) {
			fileDialogFilterNames = names;
		}

		public String getText() {
			return mText.getText();

		}

		public void setText(String string) {
			mText.setText(string);
		}

		public Text getTextControl() {
			return mText;
		}

		public File getFile() {
			String text = mText.getText();
			if (text.length() == 0)
				return null;
			return new File(text);
		}

		public String getTitle() {
			return title;
		}

		public void setTitle(String title) {
			this.title = title;
		}
	}
}
