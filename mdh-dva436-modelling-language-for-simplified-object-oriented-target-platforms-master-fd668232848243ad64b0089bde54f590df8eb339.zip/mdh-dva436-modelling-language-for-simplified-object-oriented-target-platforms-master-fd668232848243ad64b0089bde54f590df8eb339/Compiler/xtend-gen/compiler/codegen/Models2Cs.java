package compiler.codegen;

import behaviour.Assignment;
import behaviour.Behaviour;
import behaviour.Else;
import behaviour.ExprOperation;
import behaviour.Expression;
import behaviour.For;
import behaviour.FuncCall;
import behaviour.If;
import behaviour.Instansiation;
import behaviour.Operator;
import behaviour.Read;
import behaviour.Return;
import behaviour.Statement;
import behaviour.StringToInt;
import behaviour.While;
import behaviour.Write;
import classStructure.Function;
import classStructure.Structure;
import classStructure.Variable;
import com.google.common.base.Objects;
import org.eclipse.emf.common.util.EList;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.IterableExtensions;

@SuppressWarnings("all")
public class Models2Cs {
  private Behaviour behaviour = null;
  
  private Structure structure = null;
  
  public String generateCode(final Structure struct, final Behaviour behav) {
    String _xblockexpression = null;
    {
      this.behaviour = behav;
      this.structure = struct;
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("using System;");
      _builder.newLine();
      _builder.newLine();
      {
        EList<classStructure.Class> _classes = struct.getClasses();
        for(final classStructure.Class c : _classes) {
          String _ToCode = this.ToCode(c);
          _builder.append(_ToCode, "");
          _builder.newLineIfNotEmpty();
          _builder.newLine();
          _builder.newLine();
        }
      }
      {
        classStructure.Class _mainClass = this.structure.getMainClass();
        boolean _notEquals = (!Objects.equal(_mainClass, null));
        if (_notEquals) {
          _builder.append("public class ");
          classStructure.Class _mainClass_1 = this.structure.getMainClass();
          String _name = _mainClass_1.getName();
          _builder.append(_name, "");
          _builder.newLineIfNotEmpty();
          _builder.append("{");
          _builder.newLine();
          {
            classStructure.Class _mainClass_2 = this.structure.getMainClass();
            EList<Variable> _variables = _mainClass_2.getVariables();
            for(final Variable v : _variables) {
              _builder.append("\t");
              String _ToCode_1 = this.ToCode(v);
              _builder.append(_ToCode_1, "\t");
              _builder.newLineIfNotEmpty();
            }
          }
          _builder.append("\t");
          _builder.newLine();
          {
            classStructure.Class _mainClass_3 = this.structure.getMainClass();
            EList<Function> _functions = _mainClass_3.getFunctions();
            for(final Function f : _functions) {
              _builder.append("\t");
              {
                String _name_1 = f.getName();
                behaviour.Function _main = this.behaviour.getMain();
                String _name_2 = _main.getName();
                boolean _notEquals_1 = (!Objects.equal(_name_1, _name_2));
                if (_notEquals_1) {
                  String _ToCode_2 = this.ToCode(f);
                  _builder.append(_ToCode_2, "\t");
                }
              }
              _builder.newLineIfNotEmpty();
            }
          }
          _builder.append("\t");
          _builder.append("static void Main()");
          _builder.newLine();
          _builder.append("\t");
          _builder.append("{");
          _builder.newLine();
          {
            behaviour.Function _main_1 = this.behaviour.getMain();
            EList<Statement> _body = _main_1.getBody();
            for(final Statement s : _body) {
              _builder.append("\t\t");
              String _ToCode_3 = this.ToCode(s, this.structure);
              _builder.append(_ToCode_3, "\t\t");
              _builder.newLineIfNotEmpty();
            }
          }
          _builder.append("\t");
          _builder.append("}");
          _builder.newLine();
          _builder.append("}");
        }
      }
      _builder.newLineIfNotEmpty();
      {
        classStructure.Class _mainClass_4 = this.structure.getMainClass();
        boolean _equals = Objects.equal(_mainClass_4, null);
        if (_equals) {
          _builder.append("public class Program");
          _builder.newLine();
          _builder.append("{");
          _builder.newLine();
          _builder.append("\t");
          _builder.append("static void Main()");
          _builder.newLine();
          _builder.append("\t");
          _builder.append("{");
          _builder.newLine();
          {
            behaviour.Function _main_2 = this.behaviour.getMain();
            EList<Statement> _body_1 = _main_2.getBody();
            for(final Statement s_1 : _body_1) {
              _builder.append("\t\t");
              String _ToCode_4 = this.ToCode(s_1, this.structure);
              _builder.append(_ToCode_4, "\t\t");
              _builder.newLineIfNotEmpty();
            }
          }
          _builder.append("\t");
          _builder.append("}");
          _builder.newLine();
          _builder.append("}");
          _builder.newLine();
        }
      }
      _xblockexpression = _builder.toString();
    }
    return _xblockexpression;
  }
  
  public String ToCode(final classStructure.Class c) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("public class ");
    String _name = c.getName();
    _builder.append(_name, "");
    _builder.newLineIfNotEmpty();
    _builder.append("{");
    _builder.newLine();
    {
      EList<Variable> _variables = c.getVariables();
      for(final Variable v : _variables) {
        _builder.append("\t");
        String _ToCode = this.ToCode(v);
        _builder.append(_ToCode, "\t");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.newLine();
      }
    }
    {
      EList<Function> _functions = c.getFunctions();
      for(final Function f : _functions) {
        _builder.append("\t");
        String _ToCode_1 = this.ToCode(f);
        _builder.append(_ToCode_1, "\t");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.newLine();
      }
    }
    _builder.append("}");
    return _builder.toString();
  }
  
  public String ToCode(final Variable variable) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("public ");
    String _type = variable.getType();
    _builder.append(_type, "");
    _builder.append(" ");
    String _name = variable.getName();
    _builder.append(_name, "");
    _builder.append(";");
    return _builder.toString();
  }
  
  public String ToCode(final Function function) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("public ");
    String _returnType = function.getReturnType();
    _builder.append(_returnType, "");
    _builder.append(" ");
    String _name = function.getName();
    _builder.append(_name, "");
    _builder.append(" (");
    EList<Variable> _parameters = function.getParameters();
    String _paramsToString = this.paramsToString(_parameters);
    _builder.append(_paramsToString, "");
    _builder.append(")");
    _builder.newLineIfNotEmpty();
    _builder.append("{");
    _builder.newLine();
    _builder.append("\t");
    String _BodyToCode = this.BodyToCode(function);
    _builder.append(_BodyToCode, "\t");
    _builder.newLineIfNotEmpty();
    _builder.append("}");
    return _builder.toString();
  }
  
  public String paramsToString(final EList<Variable> params) {
    String res = "";
    int _length = ((Object[])Conversions.unwrapArray(params, Object.class)).length;
    boolean _greaterThan = (_length > 0);
    if (_greaterThan) {
      for (int i = 0; (i < (((Object[])Conversions.unwrapArray(params, Object.class)).length - 1)); i++) {
        String _res = res;
        Variable _get = params.get(i);
        String _type = _get.getType();
        String _plus = (_type + " ");
        Variable _get_1 = params.get(i);
        String _name = _get_1.getName();
        String _plus_1 = (_plus + _name);
        String _plus_2 = (_plus_1 + ", ");
        res = (_res + _plus_2);
      }
      String _res = res;
      Variable _last = IterableExtensions.<Variable>last(params);
      String _type = _last.getType();
      String _plus = (_type + " ");
      Variable _last_1 = IterableExtensions.<Variable>last(params);
      String _name = _last_1.getName();
      String _plus_1 = (_plus + _name);
      res = (_res + _plus_1);
    }
    return res;
  }
  
  public String BodyToCode(final Function function) {
    for (int i = 0; (i < ((Object[])Conversions.unwrapArray(this.behaviour.getFunctions(), Object.class)).length); i++) {
      EList<behaviour.Function> _functions = this.behaviour.getFunctions();
      behaviour.Function _get = _functions.get(i);
      String _name = _get.getName();
      String _name_1 = function.getName();
      boolean _equals = Objects.equal(_name, _name_1);
      if (_equals) {
        EList<behaviour.Function> _functions_1 = this.behaviour.getFunctions();
        behaviour.Function _get_1 = _functions_1.get(i);
        EList<Statement> body = _get_1.getBody();
        StringConcatenation _builder = new StringConcatenation();
        {
          for(final Statement s : body) {
            String _ToCode = this.ToCode(s, this.structure);
            _builder.append(_ToCode, "");
            _builder.newLineIfNotEmpty();
            _builder.newLine();
          }
        }
        return _builder.toString();
      }
    }
    return null;
  }
  
  public String ToCode(final Statement statement, final Structure structure) {
    String _xblockexpression = null;
    {
      if ((statement instanceof While)) {
        While w = ((While) statement);
        StringConcatenation _builder = new StringConcatenation();
        _builder.append("while(");
        Expression _condition = w.getCondition();
        String _ToCode = this.ToCode(_condition);
        _builder.append(_ToCode, "");
        _builder.append(")");
        _builder.newLineIfNotEmpty();
        _builder.append("{");
        _builder.newLine();
        {
          EList<Statement> _body = w.getBody();
          for(final Statement s : _body) {
            _builder.append("\t");
            String _ToCode_1 = this.ToCode(s, structure);
            _builder.append(_ToCode_1, "\t");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.newLine();
          }
        }
        _builder.append("}");
        return _builder.toString();
      } else {
        if ((statement instanceof For)) {
          For w_1 = ((For) statement);
          StringConcatenation _builder_1 = new StringConcatenation();
          _builder_1.append("for(");
          String _initType = w_1.getInitType();
          _builder_1.append(_initType, "");
          _builder_1.append(" ");
          String _initName = w_1.getInitName();
          _builder_1.append(_initName, "");
          {
            Expression _initAssignment = w_1.getInitAssignment();
            boolean _notEquals = (!Objects.equal(_initAssignment, null));
            if (_notEquals) {
              _builder_1.append(" = ");
              Expression _initAssignment_1 = w_1.getInitAssignment();
              String _ToCode_2 = this.ToCode(_initAssignment_1);
              _builder_1.append(_ToCode_2, "");
            }
          }
          _builder_1.append("; ");
          Expression _condition_1 = w_1.getCondition();
          String _ToCode_3 = this.ToCode(_condition_1);
          _builder_1.append(_ToCode_3, "");
          _builder_1.append("; ");
          Expression _afterthought = w_1.getAfterthought();
          String _ToCode_4 = this.ToCode(_afterthought);
          _builder_1.append(_ToCode_4, "");
          _builder_1.append(")");
          _builder_1.newLineIfNotEmpty();
          _builder_1.append("{");
          _builder_1.newLine();
          {
            EList<Statement> _body_1 = w_1.getBody();
            for(final Statement s_1 : _body_1) {
              _builder_1.append("\t");
              String _ToCode_5 = this.ToCode(s_1, structure);
              _builder_1.append(_ToCode_5, "\t");
              _builder_1.newLineIfNotEmpty();
              _builder_1.append("\t");
              _builder_1.newLine();
            }
          }
          _builder_1.append("}");
          return _builder_1.toString();
        } else {
          if ((statement instanceof If)) {
            If w_2 = ((If) statement);
            StringConcatenation _builder_2 = new StringConcatenation();
            _builder_2.append("if(");
            Expression _condition_2 = w_2.getCondition();
            String _ToCode_6 = this.ToCode(_condition_2);
            _builder_2.append(_ToCode_6, "");
            _builder_2.append(")");
            _builder_2.newLineIfNotEmpty();
            _builder_2.append("{");
            _builder_2.newLine();
            {
              EList<Statement> _body_2 = w_2.getBody();
              for(final Statement s_2 : _body_2) {
                _builder_2.append("\t");
                String _ToCode_7 = this.ToCode(s_2, structure);
                _builder_2.append(_ToCode_7, "\t");
                _builder_2.newLineIfNotEmpty();
              }
            }
            _builder_2.append("}");
            _builder_2.newLine();
            String r = _builder_2.toString();
            Else _elseStatement = w_2.getElseStatement();
            boolean _notEquals_1 = (!Objects.equal(_elseStatement, null));
            if (_notEquals_1) {
              Else _elseStatement_1 = w_2.getElseStatement();
              Else e = ((Else) _elseStatement_1);
              String _r = r;
              StringConcatenation _builder_3 = new StringConcatenation();
              _builder_3.append("else");
              _builder_3.newLine();
              _builder_3.append("{");
              _builder_3.newLine();
              {
                EList<Statement> _body_3 = e.getBody();
                for(final Statement s_3 : _body_3) {
                  _builder_3.append("\t");
                  String _ToCode_8 = this.ToCode(s_3, structure);
                  _builder_3.append(_ToCode_8, "\t");
                  _builder_3.newLineIfNotEmpty();
                }
              }
              _builder_3.append("}");
              r = (_r + _builder_3);
            }
            return r;
          } else {
            if ((statement instanceof Assignment)) {
              Assignment a = ((Assignment) statement);
              StringConcatenation _builder_4 = new StringConcatenation();
              String _variable = a.getVariable();
              _builder_4.append(_variable, "");
              _builder_4.append(" = ");
              Expression _value = a.getValue();
              String _ToCode_9 = this.ToCode(_value);
              _builder_4.append(_ToCode_9, "");
              _builder_4.append(";");
              return _builder_4.toString();
            } else {
              if ((statement instanceof Instansiation)) {
                Instansiation i = ((Instansiation) statement);
                boolean _isIsVariable = i.isIsVariable();
                if (_isIsVariable) {
                  StringConcatenation _builder_5 = new StringConcatenation();
                  String _className = i.getClassName();
                  _builder_5.append(_className, "");
                  _builder_5.append(" ");
                  String _varName = i.getVarName();
                  _builder_5.append(_varName, "");
                  _builder_5.append(";");
                  return _builder_5.toString();
                } else {
                  StringConcatenation _builder_6 = new StringConcatenation();
                  String _className_1 = i.getClassName();
                  _builder_6.append(_className_1, "");
                  _builder_6.append(" ");
                  String _varName_1 = i.getVarName();
                  _builder_6.append(_varName_1, "");
                  _builder_6.append(" = new ");
                  String _className_2 = i.getClassName();
                  _builder_6.append(_className_2, "");
                  _builder_6.append("();");
                  return _builder_6.toString();
                }
              } else {
                if ((statement instanceof Return)) {
                  Return r_1 = ((Return) statement);
                  StringConcatenation _builder_7 = new StringConcatenation();
                  _builder_7.append("return ");
                  Expression _value_1 = r_1.getValue();
                  String _ToCode_10 = this.ToCode(_value_1);
                  _builder_7.append(_ToCode_10, "");
                  _builder_7.append(";");
                  return _builder_7.toString();
                } else {
                  if ((statement instanceof Expression)) {
                    Expression expr = ((Expression) statement);
                    StringConcatenation _builder_8 = new StringConcatenation();
                    String _ToCode_11 = this.ToCode(expr);
                    _builder_8.append(_ToCode_11, "");
                    _builder_8.append(";");
                    return _builder_8.toString();
                  } else {
                    if ((statement instanceof Write)) {
                      Write w_3 = ((Write) statement);
                      StringConcatenation _builder_9 = new StringConcatenation();
                      _builder_9.append("Console.WriteLine(");
                      Expression _value_2 = w_3.getValue();
                      String _ToCode_12 = this.ToCode(_value_2);
                      _builder_9.append(_ToCode_12, "");
                      _builder_9.append(");");
                      return _builder_9.toString();
                    } else {
                      if ((statement instanceof Read)) {
                        Read r_2 = ((Read) statement);
                        StringConcatenation _builder_10 = new StringConcatenation();
                        String _variable_1 = r_2.getVariable();
                        _builder_10.append(_variable_1, "");
                        _builder_10.append(" = Console.ReadLine();");
                        return _builder_10.toString();
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
      StringConcatenation _builder_11 = new StringConcatenation();
      _builder_11.append("This Statement is not yet implemented in the codegeneration!");
      _xblockexpression = _builder_11.toString();
    }
    return _xblockexpression;
  }
  
  public String argsToString(final EList<Expression> args) {
    String res = "";
    int _length = ((Object[])Conversions.unwrapArray(args, Object.class)).length;
    boolean _greaterThan = (_length > 0);
    if (_greaterThan) {
      for (int i = 0; (i < (((Object[])Conversions.unwrapArray(args, Object.class)).length - 1)); i++) {
        String _res = res;
        Expression _get = args.get(i);
        String _ToCode = this.ToCode(_get);
        String _plus = (_ToCode + ", ");
        res = (_res + _plus);
      }
      String _res = res;
      Expression _last = IterableExtensions.<Expression>last(args);
      String _ToCode = this.ToCode(_last);
      res = (_res + _ToCode);
    }
    return res;
  }
  
  public String ToCode(final Expression expr) {
    String _xblockexpression = null;
    {
      if ((expr instanceof behaviour.Variable)) {
        StringConcatenation _builder = new StringConcatenation();
        String _val = ((behaviour.Variable) expr).getVal();
        _builder.append(_val, "");
        return _builder.toString();
      } else {
        if ((expr instanceof ExprOperation)) {
          ExprOperation exprOP = ((ExprOperation) expr);
          StringConcatenation _builder_1 = new StringConcatenation();
          EList<Expression> _operands = exprOP.getOperands();
          Expression _get = _operands.get(0);
          String _ToCode = this.ToCode(_get);
          _builder_1.append(_ToCode, "");
          _builder_1.append(" ");
          Operator _operator = exprOP.getOperator();
          String _opeToCode = this.opeToCode(_operator);
          _builder_1.append(_opeToCode, "");
          _builder_1.append(" ");
          EList<Expression> _operands_1 = exprOP.getOperands();
          Expression _get_1 = _operands_1.get(1);
          String _ToCode_1 = this.ToCode(_get_1);
          _builder_1.append(_ToCode_1, "");
          return _builder_1.toString();
        } else {
          if ((expr instanceof StringToInt)) {
            StringConcatenation _builder_2 = new StringConcatenation();
            _builder_2.append("Int32.Parse(");
            Expression _value = ((StringToInt) expr).getValue();
            String _ToCode_2 = this.ToCode(_value);
            _builder_2.append(_ToCode_2, "");
            _builder_2.append(")");
            return _builder_2.toString();
          } else {
            if ((expr instanceof FuncCall)) {
              FuncCall fc = ((FuncCall) expr);
              StringConcatenation _builder_3 = new StringConcatenation();
              String _variable = fc.getVariable();
              _builder_3.append(_variable, "");
              _builder_3.append(".");
              behaviour.Function _function = fc.getFunction();
              String _name = _function.getName();
              _builder_3.append(_name, "");
              _builder_3.append("(");
              EList<Expression> _arguments = fc.getArguments();
              String _argsToString = this.argsToString(_arguments);
              _builder_3.append(_argsToString, "");
              _builder_3.append(")");
              return _builder_3.toString();
            }
          }
        }
      }
      StringConcatenation _builder_4 = new StringConcatenation();
      _builder_4.append("ERROR in M2T code generation (Expression.ToCode)");
      _xblockexpression = _builder_4.toString();
    }
    return _xblockexpression;
  }
  
  public String opeToCode(final Operator expr) {
    if (expr != null) {
      switch (expr) {
        case EQUAL:
          StringConcatenation _builder = new StringConcatenation();
          _builder.append("==");
          return _builder.toString();
        case INEQUAL:
          StringConcatenation _builder_1 = new StringConcatenation();
          _builder_1.append("!=");
          return _builder_1.toString();
        case LESS_THAN:
          StringConcatenation _builder_2 = new StringConcatenation();
          _builder_2.append("<");
          return _builder_2.toString();
        case GREATER_THAN:
          StringConcatenation _builder_3 = new StringConcatenation();
          _builder_3.append(">");
          return _builder_3.toString();
        case LESS_OR_EQUAL_THAN:
          StringConcatenation _builder_4 = new StringConcatenation();
          _builder_4.append("<=");
          return _builder_4.toString();
        case GREATER_OR_EQUAL_THAN:
          StringConcatenation _builder_5 = new StringConcatenation();
          _builder_5.append(">=");
          return _builder_5.toString();
        case AND:
          StringConcatenation _builder_6 = new StringConcatenation();
          _builder_6.append("&&");
          return _builder_6.toString();
        case OR:
          StringConcatenation _builder_7 = new StringConcatenation();
          _builder_7.append("||");
          return _builder_7.toString();
        case SUM:
          StringConcatenation _builder_8 = new StringConcatenation();
          _builder_8.append("+");
          return _builder_8.toString();
        case DIFFERENCE:
          StringConcatenation _builder_9 = new StringConcatenation();
          _builder_9.append("-");
          return _builder_9.toString();
        case MULTIPLICATION:
          StringConcatenation _builder_10 = new StringConcatenation();
          _builder_10.append("*");
          return _builder_10.toString();
        case DIVISION:
          StringConcatenation _builder_11 = new StringConcatenation();
          _builder_11.append("/");
          return _builder_11.toString();
        case MODULUS:
          StringConcatenation _builder_12 = new StringConcatenation();
          _builder_12.append("%");
          return _builder_12.toString();
        default:
          break;
      }
    }
    return null;
  }
}
