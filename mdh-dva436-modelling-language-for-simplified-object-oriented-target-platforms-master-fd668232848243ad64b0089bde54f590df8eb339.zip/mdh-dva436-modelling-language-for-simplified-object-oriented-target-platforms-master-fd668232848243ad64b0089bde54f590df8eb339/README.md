# MDH/DVA436 - Modelling language for simplified Object-Oriented target platforms

Albi Dode,
Thalamas Joris,
Jonas Skoog,
Martin Váňa

---

## Task
### Description
* Design a modelling language for simplified Object-Oriented target platforms
* The language exploits separation of concerns by means of two different metamodels
    * one for the structure of the program
    * one for the behaviour of the program
* The structure contains (at least) classes, their attributes and methods
* The behaviour should allow (at least) assignments, a conditional expression, and an iteration construct (while, for, etc)

### Goals
* To define one language (metamodel) for the structure
* To define one language (metamodel) for the behaviour
* (Optional) To define a M2M transformation in QVTo that from two input models (structure model and behaviour model) generates an intermediate model (conforming to a metamodel, different from the previous two, that you should define as well)
* To define an M2T transformation in Xtend that from two input models (structure model and behaviour model) generate code in a selected target programming language (e.g. Java, C++)

### Notes
* You can take inspiration from existing metamodels for structural and behavioural modelling (cite appropriately in the report)
* The complexity/expressiveness of the modelling languages is your choice
* All the concepts included in the languages (metamodels) have to be taken care of by the M2T transformation

### Project report
The project report should contain:
* A description of the metamodels with their intended use
* A description of the transformation(s)
* The case study implemented by the group
* A description of the steps for running the project
* Limitations and possible future extensions

---

## Prerequisites

* [Eclipse Modeling Tools](http://www.eclipse.org/downloads/packages/eclipse-modeling-tools/mars2) (Developed using *Mars* version)

* [Xtend](https://eclipse.org/xtend/index.html) Can be installed by clicking on `Help -> Eclipse Marketplace...`, search for `Xtend`(version 2.9.1 in my case) and install it.

---

## Build & Run

1. Import `Behaviour`, `ClassStructure`, `Compiler`, `Compiler.ui` folders by clicking on `File -> Import...` and following the *Import wizard*.

2. In the `Behaviour` and `ClassStructure` folders, there are meta-model themselves. To generate other folders open files `Behaviour/model/behaviour.genmodel` and `Behaviour/model/classStructure.genmodel` Open menu by right clicking on the content of these files (on the root element) and select *Generate All*.

4. You should be able to run the application by right clicking on `Behaviour` project (or any other) and selecting `Run As -> <XX>. Eclipse Application`.

### Development Notes

These notes are for solving import problems. Changes in *Build Path* removes import errors in Eclipse and during build. Changes in *MANIFEST.MF* (classpath) removes `java.lang.ClassNotFoundException` on runtime.

#### Compiler

`Compiler` project has following dependencies which has to be added to *Build Path* (Right click on project and select `Build Path -> Configure Build Path...`):

* Projects
    * Behaviour
    * ClassStructure


* Libraries
    * Xtend Library

And to the tab `Dependencies` in `MANIFEST.MF` you need to add:

* Behaviour
* ClassStructure
* `org.eclipse.xtend.standalone`

#### Compiler.ui

`Compiler.ui` project has following dependencies which has to be added to *Build Path* (Right click on project and select `Build Path -> Configure Build Path...`):

* Projects
    * Compiler
    * Behaviour
    * ClassStructure

And to the tab `Dependencies` in `MANIFEST.MF` you need to add:

* Compiler
* Behaviour
* `org.eclipse.core.resources`
* `org.eclipse.emf.ecore.xmi`

---

## Usage

1. Import `ProgramModels` folders by clicking on `File -> Import...` and following the *Import wizard*.

2. Click on `Generate Code` button in the main toolbar and follow wizard.

---

## Sources

* [Kiel University - Tutorials](http://rtsys.informatik.uni-kiel.de/confluence/display/TUT/Tutorials)
* [Eclipse Modeling Framework (EMF) - Persisting models via XMI - Tutorial](http://www.vogella.com/tutorials/EclipseEMFPersistence/article.html)
